import { drizzle } from "drizzle-orm/mysql2";
import { createConnection } from "mysql2/promise";
import * as schema from "./schema";
import dotenv from "dotenv";
import path from "path";

dotenv.config({ path: path.resolve(process.cwd(), ".env") });

async function seed() {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    throw new Error("DATABASE_URL not found");
  }

  const connection = await createConnection(dbUrl);
  const db = drizzle(connection, { schema, mode: "planetscale" });

  // Seed sample songs
  await db.insert(schema.songs).values([
    {
      title: "Midnight Rain",
      artist: "Luna Echo",
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
      coverUrl: "/gallery/photo1.jpg",
      duration: 372,
    },
    {
      title: "Autumn Leaves",
      artist: "The Wanderers",
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
      coverUrl: "/gallery/photo5.jpg",
      duration: 289,
    },
    {
      title: "Ocean Dreams",
      artist: "Saltwater",
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
      coverUrl: "/gallery/photo9.jpg",
      duration: 415,
    },
    {
      title: "Candlelight",
      artist: "Velvet Room",
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
      coverUrl: "/gallery/photo8.jpg",
      duration: 198,
    },
    {
      title: "Theater of Memories",
      artist: "Ghost Ensemble",
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
      coverUrl: "/gallery/photo3.jpg",
      duration: 356,
    },
    {
      title: "Park Bench Lullaby",
      artist: "Fog Harbor",
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3",
      coverUrl: "/gallery/photo6.jpg",
      duration: 267,
    },
  ]);

  // Seed sample photos
  await db.insert(schema.photos).values([
    {
      title: "The Long Road Ahead",
      description: "A solitary journey through misty mountain passes at dawn",
      imageUrl: "/gallery/photo1.jpg",
    },
    {
      title: "Fading Memories",
      description: "Weathered hands holding onto the past",
      imageUrl: "/gallery/photo2.jpg",
    },
    {
      title: "Echoes of Applause",
      description: "An abandoned theater frozen in time",
      imageUrl: "/gallery/photo3.jpg",
    },
    {
      title: "Rainy Day Commute",
      description: "City lights through rain-soaked windows",
      imageUrl: "/gallery/photo4.jpg",
    },
    {
      title: "Letters Never Sent",
      description: "A collection of handwritten letters bound by time",
      imageUrl: "/gallery/photo5.jpg",
    },
    {
      title: "Empty Playground",
      description: "Fog settles over childhood memories",
      imageUrl: "/gallery/photo6.jpg",
    },
    {
      title: "Vinyl Dreams",
      description: "Scattered records on a dark floor",
      imageUrl: "/gallery/photo7.jpg",
    },
    {
      title: "Melting Moments",
      description: "Candlelit dinner for two who are no more",
      imageUrl: "/gallery/photo8.jpg",
    },
    {
      title: "Horizon's Edge",
      description: "Sunset crashing against ancient rocks",
      imageUrl: "/gallery/photo9.jpg",
    },
    {
      title: "Reflections",
      description: "A vintage mirror holding secrets of the hallway",
      imageUrl: "/gallery/photo10.jpg",
    },
  ]);

  console.log("Seed complete!");
  await connection.end();
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
