import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Music, Image, ChevronDown, Disc3, Clock, Heart } from "lucide-react";
import MusicPlayer from "@/components/MusicPlayer";
import PhotoGallery from "@/components/PhotoGallery";
import gsap from "gsap";

export default function Home() {
  const { user } = useAuth();
  const heroRef = useRef<HTMLDivElement>(null);
  const galleryRef = useRef<HTMLDivElement>(null);
  const musicRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const scrollLineRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [heroLoaded, setHeroLoaded] = useState(false);

  const { data: songsData, isLoading: songsLoading } = trpc.song.list.useQuery();
  const { data: photosData, isLoading: photosLoading } = trpc.photo.list.useQuery();

  const songs = songsData ?? [];
  const photos = photosData ?? [];

  // Hero entrance animation
  useEffect(() => {
    if (!heroLoaded) return;
    const tl = gsap.timeline();
    tl.fromTo(
      titleRef.current,
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 1.2, ease: "power3.out" }
    );
    tl.fromTo(
      subtitleRef.current,
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.8, ease: "power3.out" },
      "-=0.6"
    );
    tl.fromTo(
      scrollLineRef.current,
      { scaleY: 0 },
      { scaleY: 1, duration: 0.8, ease: "power3.out" },
      "-=0.4"
    );
  }, [heroLoaded]);

  // Canvas particle effect for hero
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      alpha: number;
    }> = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    // Create particles
    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 2 + 0.5,
        alpha: Math.random() * 0.5 + 0.1,
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(226, 226, 226, ${p.alpha})`;
        ctx.fill();
      });

      // Draw connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(226, 226, 226, ${0.08 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      animId = requestAnimationFrame(draw);
    };

    draw();
    setHeroLoaded(true);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  // Gallery section animation
  useEffect(() => {
    if (!galleryRef.current || photos.length === 0) return;
    const el = galleryRef.current;
    gsap.fromTo(
      el.querySelector(".section-header"),
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: el,
          start: "top 75%",
        },
      }
    );
  }, [photos]);

  // Music section animation
  useEffect(() => {
    if (!musicRef.current || songs.length === 0) return;
    const el = musicRef.current;
    gsap.fromTo(
      el.querySelector(".section-header"),
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: el,
          start: "top 75%",
        },
      }
    );
  }, [songs]);

  return (
    <div className="min-h-screen bg-[#050505]">
      {/* Hero Section */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
      >
        <canvas
          ref={canvasRef}
          className="absolute inset-0 z-0"
        />

        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
          <h1
            ref={titleRef}
            className="text-[clamp(3rem,7vw,6rem)] font-normal leading-[0.9] tracking-[-0.02em] text-[#e2e2e2] opacity-0"
            style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 300 }}
          >
            Reminiscence
          </h1>
          <p
            ref={subtitleRef}
            className="mt-6 text-lg md:text-xl text-[#e2e2e2]/50 font-light tracking-wide opacity-0"
          >
            An archive of fleeting moments and melodies
          </p>

          {user?.role === "admin" && (
            <div className="mt-8 fade-in">
              <Link
                to="/admin"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#e2e2e2]/10 border border-[#e2e2e2]/20 text-sm text-[#e2e2e2]/70 hover:text-[#e2e2e2] hover:bg-[#e2e2e2]/15 hover:border-[#e2e2e2]/30 transition-all duration-300"
              >
                <Disc3 size={16} />
                Manage Memories
              </Link>
            </div>
          )}
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-3">
          <span className="text-[10px] tracking-[0.15em] uppercase text-[#e2e2e2]/30 font-mono">
            Scroll
          </span>
          <div
            ref={scrollLineRef}
            className="w-px h-12 bg-gradient-to-b from-[#e2e2e2]/40 to-transparent origin-top"
            style={{ transform: "scaleY(0)" }}
          >
            <div className="w-full h-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section
        id="gallery"
        ref={galleryRef}
        className="relative py-24 md:py-32 px-6 lg:px-10 max-w-[1400px] mx-auto"
      >
        <div className="section-header flex items-center gap-4 mb-12">
          <div className="w-10 h-10 rounded-xl bg-[#1c1c1c]/60 flex items-center justify-center">
            <Image size={18} className="text-[#e2e2e2]/60" />
          </div>
          <div>
            <h2 className="text-2xl md:text-3xl font-normal text-[#e2e2e2] tracking-tight">
              Photo Gallery
            </h2>
            <p className="text-sm text-[#e2e2e2]/40 mt-1">
              {photos.length} memories captured
            </p>
          </div>
        </div>

        {photosLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 auto-rows-[220px]">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="bg-[#1c1c1c]/30 rounded-2xl animate-pulse"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        ) : photos.length > 0 ? (
          <PhotoGallery photos={photos} />
        ) : (
          <div className="text-center py-20">
            <Image size={48} className="mx-auto text-[#e2e2e2]/15 mb-4" />
            <p className="text-[#e2e2e2]/30 text-sm">No photos yet. Upload from the admin dashboard.</p>
          </div>
        )}
      </section>

      {/* Divider */}
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="h-px bg-gradient-to-r from-transparent via-[#333]/50 to-transparent" />
      </div>

      {/* Music Section */}
      <section
        id="music"
        ref={musicRef}
        className="relative py-24 md:py-32 px-6 lg:px-10 max-w-[1400px] mx-auto"
      >
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Left - Info */}
          <div className="lg:col-span-2">
            <div className="section-header flex items-center gap-4 mb-8">
              <div className="w-10 h-10 rounded-xl bg-[#1c1c1c]/60 flex items-center justify-center">
                <Music size={18} className="text-[#e2e2e2]/60" />
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-normal text-[#e2e2e2] tracking-tight">
                  Music Collection
                </h2>
                <p className="text-sm text-[#e2e2e2]/40 mt-1">
                  {songs.length} tracks curated
                </p>
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 text-sm text-[#e2e2e2]/50">
                <Disc3 size={16} className="text-[#e2e2e2]/30" />
                <span>Personal playlist</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-[#e2e2e2]/50">
                <Clock size={16} className="text-[#e2e2e2]/30" />
                <span>
                  {songs.reduce((acc, s) => acc + (s.duration || 0), 0) > 0
                    ? `${Math.floor(songs.reduce((acc, s) => acc + (s.duration || 0), 0) / 60)} min`
                    : "Various lengths"}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm text-[#e2e2e2]/50">
                <Heart size={16} className="text-[#e2e2e2]/30" />
                <span>Favorite melodies</span>
              </div>
            </div>

            {/* Decorative element */}
            <div className="hidden lg:block mt-12">
              <div className="w-32 h-32 rounded-full border border-[#333]/30 flex items-center justify-center">
                <div className="w-24 h-24 rounded-full border border-[#333]/20 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full border border-[#333]/10 flex items-center justify-center">
                    <Disc3 size={24} className="text-[#e2e2e2]/20 animate-spin" style={{ animationDuration: "8s" }} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Player */}
          <div className="lg:col-span-3">
            {songsLoading ? (
              <div className="space-y-4">
                <div className="glass-card rounded-2xl p-6 h-48 animate-pulse" />
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="glass-card rounded-xl p-4 h-16 animate-pulse" style={{ animationDelay: `${i * 0.1}s` }} />
                ))}
              </div>
            ) : songs.length > 0 ? (
              <MusicPlayer songs={songs} />
            ) : (
              <div className="text-center py-20 glass-card rounded-2xl">
                <Music size={48} className="mx-auto text-[#e2e2e2]/15 mb-4" />
                <p className="text-[#e2e2e2]/30 text-sm">No songs yet. Upload from the admin dashboard.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-[#333]/30">
        <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#e2e2e2]/30 font-mono tracking-wider">
            REMINISCENCE
          </p>
          <p className="text-xs text-[#e2e2e2]/20">
            A digital archive of memories and melodies
          </p>
        </div>
      </footer>
    </div>
  );
}
