import { useEffect, useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import {
  Music,
  Image,
  Upload,
  Trash2,
  Plus,
  X,
  Pencil,
  Disc3,
  Users,
  Loader2,
  ChevronLeft,
  Save,
  Clock,
  Volume2,
} from "lucide-react";
import gsap from "gsap";

type Tab = "songs" | "photos";
type ModalMode = "create" | "edit" | null;

interface SongFormData {
  id?: number;
  title: string;
  artist: string;
  audioUrl: string;
  coverUrl: string;
  duration: number;
}

interface PhotoFormData {
  id?: number;
  title: string;
  description: string;
  imageUrl: string;
}

export default function Admin() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("songs");
  const [modalMode, setModalMode] = useState<ModalMode>(null);
  const [editingSong, setEditingSong] = useState<SongFormData | null>(null);
  const [editingPhoto, setEditingPhoto] = useState<PhotoFormData | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  // Redirect non-admin
  useEffect(() => {
    if (!authLoading && (!isAuthenticated || user?.role !== "admin")) {
      navigate("/");
    }
  }, [authLoading, isAuthenticated, user, navigate]);

  const utils = trpc.useUtils();
  const { data: songsData, isLoading: songsLoading } = trpc.song.list.useQuery();
  const { data: photosData, isLoading: photosLoading } = trpc.photo.list.useQuery();

  const createSong = trpc.song.create.useMutation({
    onSuccess: () => {
      utils.song.list.invalidate();
      closeModal();
    },
  });
  const updateSong = trpc.song.update.useMutation({
    onSuccess: () => {
      utils.song.list.invalidate();
      closeModal();
    },
  });
  const deleteSong = trpc.song.delete.useMutation({
    onSuccess: () => {
      utils.song.list.invalidate();
      setDeleteConfirm(null);
    },
  });

  const createPhoto = trpc.photo.create.useMutation({
    onSuccess: () => {
      utils.photo.list.invalidate();
      closeModal();
    },
  });
  const updatePhoto = trpc.photo.update.useMutation({
    onSuccess: () => {
      utils.photo.list.invalidate();
      closeModal();
    },
  });
  const deletePhoto = trpc.photo.delete.useMutation({
    onSuccess: () => {
      utils.photo.list.invalidate();
      setDeleteConfirm(null);
    },
  });

  const closeModal = () => {
    setModalMode(null);
    setEditingSong(null);
    setEditingPhoto(null);
  };

  const handleUpload = useCallback(
    async (file: File, type: "image" | "audio"): Promise<string | null> => {
      setUploading(true);
      try {
        const formData = new FormData();
        formData.append("file", file);
        formData.append("type", type);
        const res = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        });
        const data = await res.json();
        if (data.url) return data.url;
        return null;
      } catch {
        return null;
      } finally {
        setUploading(false);
      }
    },
    []
  );

  // Entrance animation
  useEffect(() => {
    if (contentRef.current) {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.6, ease: "power3.out" }
      );
    }
  }, []);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <Loader2 size={24} className="text-[#e2e2e2]/40 animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") return null;

  const songs = songsData ?? [];
  const photos = photosData ?? [];

  return (
    <div className="min-h-screen bg-[#050505] pt-20 pb-12" ref={contentRef}>
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="mb-10">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-xs text-[#e2e2e2]/40 hover:text-[#e2e2e2]/70 transition-colors mb-6"
          >
            <ChevronLeft size={14} />
            Back to Home
          </button>
          <h1 className="text-3xl md:text-4xl font-light text-[#e2e2e2] tracking-tight">
            Dashboard
          </h1>
          <p className="text-sm text-[#e2e2e2]/40 mt-2">
            Manage your memories collection
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-10">
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg bg-[#e2e2e2]/5 flex items-center justify-center">
                <Music size={16} className="text-[#e2e2e2]/50" />
              </div>
              <span className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider">
                Songs
              </span>
            </div>
            <p className="text-3xl font-light text-[#e2e2e2]">{songs.length}</p>
          </div>
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg bg-[#e2e2e2]/5 flex items-center justify-center">
                <Image size={16} className="text-[#e2e2e2]/50" />
              </div>
              <span className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider">
                Photos
              </span>
            </div>
            <p className="text-3xl font-light text-[#e2e2e2]">{photos.length}</p>
          </div>
          <div className="glass-card rounded-2xl p-6 col-span-2 md:col-span-1">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg bg-[#e2e2e2]/5 flex items-center justify-center">
                <Users size={16} className="text-[#e2e2e2]/50" />
              </div>
              <span className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider">
                Role
              </span>
            </div>
            <p className="text-lg font-light text-[#e2e2e2] capitalize">{user?.role}</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 mb-8 border-b border-[#333]/30 pb-1">
          <button
            onClick={() => setActiveTab("songs")}
            className={`flex items-center gap-2 px-5 py-3 text-sm transition-all duration-300 border-b-2 ${
              activeTab === "songs"
                ? "border-[#e2e2e2]/60 text-[#e2e2e2]"
                : "border-transparent text-[#e2e2e2]/40 hover:text-[#e2e2e2]/60"
            }`}
          >
            <Music size={16} />
            Songs
          </button>
          <button
            onClick={() => setActiveTab("photos")}
            className={`flex items-center gap-2 px-5 py-3 text-sm transition-all duration-300 border-b-2 ${
              activeTab === "photos"
                ? "border-[#e2e2e2]/60 text-[#e2e2e2]"
                : "border-transparent text-[#e2e2e2]/40 hover:text-[#e2e2e2]/60"
            }`}
          >
            <Image size={16} />
            Photos
          </button>
          <div className="flex-1" />
          <button
            onClick={() => {
              if (activeTab === "songs") {
                setEditingSong({ title: "", artist: "", audioUrl: "", coverUrl: "", duration: 0 });
                setModalMode("create");
              } else {
                setEditingPhoto({ title: "", description: "", imageUrl: "" });
                setModalMode("create");
              }
            }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#e2e2e2] text-[#050505] text-sm font-medium hover:bg-white transition-colors duration-300"
          >
            <Plus size={16} />
            Add {activeTab === "songs" ? "Song" : "Photo"}
          </button>
        </div>

        {/* Songs Table */}
        {activeTab === "songs" && (
          <div>
            {songsLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 size={24} className="text-[#e2e2e2]/40 animate-spin" />
              </div>
            ) : songs.length === 0 ? (
              <div className="text-center py-20 glass-card rounded-2xl">
                <Music size={48} className="mx-auto text-[#e2e2e2]/15 mb-4" />
                <p className="text-[#e2e2e2]/30 text-sm">No songs yet. Add your first song.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {songs.map((song) => (
                  <div
                    key={song.id}
                    className="glass-card rounded-xl p-4 flex items-center gap-4 group hover:bg-[#1c1c1c]/80 transition-all duration-300"
                  >
                    <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={song.coverUrl}
                        alt={song.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-[#e2e2e2] truncate">{song.title}</p>
                      <p className="text-xs text-[#e2e2e2]/40 mt-0.5">{song.artist}</p>
                    </div>
                    <div className="hidden sm:flex items-center gap-6 text-xs text-[#e2e2e2]/30">
                      <span className="flex items-center gap-1">
                        <Clock size={12} />
                        {song.duration ? `${Math.floor(song.duration / 60)}:${(song.duration % 60).toString().padStart(2, "0")}` : "--:--"}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => {
                          setEditingSong({
                            id: song.id,
                            title: song.title,
                            artist: song.artist,
                            audioUrl: song.audioUrl,
                            coverUrl: song.coverUrl,
                            duration: song.duration ?? 0,
                          });
                          setModalMode("edit");
                        }}
                        className="p-2 rounded-lg text-[#e2e2e2]/40 hover:text-[#e2e2e2] hover:bg-[#e2e2e2]/10 transition-all"
                      >
                        <Pencil size={14} />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(song.id)}
                        className="p-2 rounded-lg text-red-400/40 hover:text-red-400 hover:bg-red-400/10 transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Photos Table */}
        {activeTab === "photos" && (
          <div>
            {photosLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 size={24} className="text-[#e2e2e2]/40 animate-spin" />
              </div>
            ) : photos.length === 0 ? (
              <div className="text-center py-20 glass-card rounded-2xl">
                <Image size={48} className="mx-auto text-[#e2e2e2]/15 mb-4" />
                <p className="text-[#e2e2e2]/30 text-sm">No photos yet. Add your first photo.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {photos.map((photo) => (
                  <div
                    key={photo.id}
                    className="glass-card rounded-xl overflow-hidden group hover:bg-[#1c1c1c]/80 transition-all duration-300"
                  >
                    <div className="aspect-[4/3] overflow-hidden">
                      <img
                        src={photo.imageUrl}
                        alt={photo.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-4">
                      <p className="text-sm font-medium text-[#e2e2e2] truncate">{photo.title}</p>
                      {photo.description && (
                        <p className="text-xs text-[#e2e2e2]/40 mt-1 line-clamp-2">{photo.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => {
                            setEditingPhoto({
                              id: photo.id,
                              title: photo.title,
                              description: photo.description ?? "",
                              imageUrl: photo.imageUrl,
                            });
                            setModalMode("edit");
                          }}
                          className="p-1.5 rounded-lg text-[#e2e2e2]/40 hover:text-[#e2e2e2] hover:bg-[#e2e2e2]/10 transition-all"
                        >
                          <Pencil size={12} />
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(photo.id)}
                          className="p-1.5 rounded-lg text-red-400/40 hover:text-red-400 hover:bg-red-400/10 transition-all"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Song Modal */}
      {modalMode && editingSong && (
        <SongModal
          mode={modalMode}
          data={editingSong}
          onClose={closeModal}
          onSave={(data) => {
            if (modalMode === "create") {
              createSong.mutate(data);
            } else if (data.id) {
              updateSong.mutate({ id: data.id, ...data });
            }
          }}
          onUpload={handleUpload}
          uploading={uploading}
          isSubmitting={createSong.isPending || updateSong.isPending}
        />
      )}

      {/* Photo Modal */}
      {modalMode && editingPhoto && (
        <PhotoModal
          mode={modalMode}
          data={editingPhoto}
          onClose={closeModal}
          onSave={(data) => {
            if (modalMode === "create") {
              createPhoto.mutate(data);
            } else if (data.id) {
              updatePhoto.mutate({ id: data.id, ...data });
            }
          }}
          onUpload={handleUpload}
          uploading={uploading}
          isSubmitting={createPhoto.isPending || updatePhoto.isPending}
        />
      )}

      {/* Delete Confirm */}
      {deleteConfirm !== null && (
        <div className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 fade-in">
          <div className="glass-card rounded-2xl p-8 max-w-sm w-full scale-in">
            <div className="w-12 h-12 rounded-full bg-red-400/10 flex items-center justify-center mx-auto mb-4">
              <Trash2 size={20} className="text-red-400" />
            </div>
            <h3 className="text-lg font-medium text-[#e2e2e2] text-center">
              Delete {activeTab === "songs" ? "Song" : "Photo"}?
            </h3>
            <p className="text-sm text-[#e2e2e2]/40 text-center mt-2">
              This action cannot be undone.
            </p>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 py-2.5 rounded-xl border border-[#333] text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] hover:border-[#555] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (activeTab === "songs") {
                    deleteSong.mutate({ id: deleteConfirm });
                  } else {
                    deletePhoto.mutate({ id: deleteConfirm });
                  }
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-400 text-sm text-white hover:bg-red-500 transition-all"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Song Modal ─── */
function SongModal({
  mode,
  data,
  onClose,
  onSave,
  onUpload,
  uploading,
  isSubmitting,
}: {
  mode: ModalMode;
  data: SongFormData;
  onClose: () => void;
  onSave: (data: SongFormData) => void;
  onUpload: (file: File, type: "image" | "audio") => Promise<string | null>;
  uploading: boolean;
  isSubmitting: boolean;
}) {
  const [form, setForm] = useState(data);
  const [audioUploading, setAudioUploading] = useState(false);
  const [coverUploading, setCoverUploading] = useState(false);

  const handleAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAudioUploading(true);
    const url = await onUpload(file, "audio");
    if (url) setForm((f) => ({ ...f, audioUrl: url }));
    setAudioUploading(false);
  };

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCoverUploading(true);
    const url = await onUpload(file, "image");
    if (url) setForm((f) => ({ ...f, coverUrl: url }));
    setCoverUploading(false);
  };

  const canSubmit = form.title && form.artist && form.audioUrl && form.coverUrl && !isSubmitting;

  return (
    <div className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 fade-in">
      <div className="glass-card rounded-2xl p-8 max-w-lg w-full scale-in max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-light text-[#e2e2e2]">
            {mode === "create" ? "Add Song" : "Edit Song"}
          </h3>
          <button onClick={onClose} className="text-[#e2e2e2]/40 hover:text-[#e2e2e2] transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-5">
          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Title
            </label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              className="w-full bg-[#1c1c1c]/60 border border-[#333] rounded-xl px-4 py-3 text-sm text-[#e2e2e2] placeholder-[#e2e2e2]/20 focus:outline-none focus:border-[#555] transition-colors"
              placeholder="Song title"
            />
          </div>

          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Artist
            </label>
            <input
              type="text"
              value={form.artist}
              onChange={(e) => setForm((f) => ({ ...f, artist: e.target.value }))}
              className="w-full bg-[#1c1c1c]/60 border border-[#333] rounded-xl px-4 py-3 text-sm text-[#e2e2e2] placeholder-[#e2e2e2]/20 focus:outline-none focus:border-[#555] transition-colors"
              placeholder="Artist name"
            />
          </div>

          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Duration (seconds)
            </label>
            <input
              type="number"
              value={form.duration || ""}
              onChange={(e) => setForm((f) => ({ ...f, duration: parseInt(e.target.value) || 0 }))}
              className="w-full bg-[#1c1c1c]/60 border border-[#333] rounded-xl px-4 py-3 text-sm text-[#e2e2e2] placeholder-[#e2e2e2]/20 focus:outline-none focus:border-[#555] transition-colors"
              placeholder="Duration in seconds"
            />
          </div>

          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Audio File
            </label>
            <div className="flex items-center gap-3">
              <label className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl border border-dashed border-[#333] cursor-pointer hover:border-[#555] transition-colors">
                <Upload size={16} className="text-[#e2e2e2]/40" />
                <span className="text-sm text-[#e2e2e2]/40">
                  {audioUploading ? "Uploading..." : form.audioUrl ? "Change file" : "Choose audio file"}
                </span>
                <input
                  type="file"
                  accept="audio/*"
                  onChange={handleAudioUpload}
                  className="hidden"
                  disabled={uploading}
                />
              </label>
              {form.audioUrl && (
                <span className="text-xs text-green-400/60">Saved</span>
              )}
            </div>
            {form.audioUrl && (
              <div className="flex items-center gap-2 mt-2">
                <Volume2 size={12} className="text-[#e2e2e2]/30" />
                <span className="text-xs text-[#e2e2e2]/30 truncate max-w-xs">{form.audioUrl}</span>
              </div>
            )}
          </div>

          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Cover Image
            </label>
            <div className="flex items-center gap-3">
              <label className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl border border-dashed border-[#333] cursor-pointer hover:border-[#555] transition-colors">
                <Upload size={16} className="text-[#e2e2e2]/40" />
                <span className="text-sm text-[#e2e2e2]/40">
                  {coverUploading ? "Uploading..." : form.coverUrl ? "Change image" : "Choose cover image"}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleCoverUpload}
                  className="hidden"
                  disabled={uploading}
                />
              </label>
              {form.coverUrl && (
                <span className="text-xs text-green-400/60">Saved</span>
              )}
            </div>
            {form.coverUrl && (
              <div className="mt-3 w-20 h-20 rounded-lg overflow-hidden">
                <img src={form.coverUrl} alt="Cover" className="w-full h-full object-cover" />
              </div>
            )}
          </div>
        </div>

        <div className="flex gap-3 mt-8">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl border border-[#333] text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] hover:border-[#555] transition-all"
          >
            Cancel
          </button>
          <button
            onClick={() => canSubmit && onSave(form)}
            disabled={!canSubmit}
            className={`flex-1 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all ${
              canSubmit
                ? "bg-[#e2e2e2] text-[#050505] hover:bg-white"
                : "bg-[#333] text-[#e2e2e2]/30 cursor-not-allowed"
            }`}
          >
            {isSubmitting ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Save size={16} />
            )}
            {mode === "create" ? "Add Song" : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Photo Modal ─── */
function PhotoModal({
  mode,
  data,
  onClose,
  onSave,
  onUpload,
  uploading,
  isSubmitting,
}: {
  mode: ModalMode;
  data: PhotoFormData;
  onClose: () => void;
  onSave: (data: PhotoFormData) => void;
  onUpload: (file: File, type: "image" | "audio") => Promise<string | null>;
  uploading: boolean;
  isSubmitting: boolean;
}) {
  const [form, setForm] = useState(data);
  const [imageUploading, setImageUploading] = useState(false);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageUploading(true);
    const url = await onUpload(file, "image");
    if (url) setForm((f) => ({ ...f, imageUrl: url }));
    setImageUploading(false);
  };

  const canSubmit = form.title && form.imageUrl && !isSubmitting;

  return (
    <div className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 fade-in">
      <div className="glass-card rounded-2xl p-8 max-w-lg w-full scale-in">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-light text-[#e2e2e2]">
            {mode === "create" ? "Add Photo" : "Edit Photo"}
          </h3>
          <button onClick={onClose} className="text-[#e2e2e2]/40 hover:text-[#e2e2e2] transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-5">
          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Title
            </label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              className="w-full bg-[#1c1c1c]/60 border border-[#333] rounded-xl px-4 py-3 text-sm text-[#e2e2e2] placeholder-[#e2e2e2]/20 focus:outline-none focus:border-[#555] transition-colors"
              placeholder="Photo title"
            />
          </div>

          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Description
            </label>
            <textarea
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              className="w-full bg-[#1c1c1c]/60 border border-[#333] rounded-xl px-4 py-3 text-sm text-[#e2e2e2] placeholder-[#e2e2e2]/20 focus:outline-none focus:border-[#555] transition-colors resize-none"
              rows={3}
              placeholder="Optional description"
            />
          </div>

          <div>
            <label className="text-xs text-[#e2e2e2]/40 font-mono uppercase tracking-wider mb-2 block">
              Photo
            </label>
            <div className="flex items-center gap-3">
              <label className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl border border-dashed border-[#333] cursor-pointer hover:border-[#555] transition-colors">
                <Upload size={16} className="text-[#e2e2e2]/40" />
                <span className="text-sm text-[#e2e2e2]/40">
                  {imageUploading ? "Uploading..." : form.imageUrl ? "Change photo" : "Choose photo"}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={uploading}
                />
              </label>
              {form.imageUrl && (
                <span className="text-xs text-green-400/60">Saved</span>
              )}
            </div>
            {form.imageUrl && (
              <div className="mt-3 w-full aspect-video rounded-lg overflow-hidden">
                <img src={form.imageUrl} alt="Preview" className="w-full h-full object-cover" />
              </div>
            )}
          </div>
        </div>

        <div className="flex gap-3 mt-8">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl border border-[#333] text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] hover:border-[#555] transition-all"
          >
            Cancel
          </button>
          <button
            onClick={() => canSubmit && onSave(form)}
            disabled={!canSubmit}
            className={`flex-1 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all ${
              canSubmit
                ? "bg-[#e2e2e2] text-[#050505] hover:bg-white"
                : "bg-[#333] text-[#e2e2e2]/30 cursor-not-allowed"
            }`}
          >
            {isSubmitting ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Save size={16} />
            )}
            {mode === "create" ? "Add Photo" : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}
