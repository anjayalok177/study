import { useState, useRef, useEffect, useCallback } from "react";
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Heart } from "lucide-react";
import type { Song } from "@db/schema";

interface MusicPlayerProps {
  songs: Song[];
}

export default function MusicPlayer({ songs }: MusicPlayerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [isMuted, setIsMuted] = useState(false);
  const [liked, setLiked] = useState<Set<number>>(new Set());
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  const currentSong = songs[currentIndex] ?? null;

  useEffect(() => {
    if (audioRef.current && currentSong) {
      audioRef.current.src = currentSong.audioUrl;
      audioRef.current.load();
      if (isPlaying) {
        audioRef.current.play().catch(() => setIsPlaying(false));
      }
    }
  }, [currentSong?.id]);

  useEffect(() => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.play().catch(() => setIsPlaying(false));
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying]);

  const handleTimeUpdate = useCallback(() => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  }, []);

  const handleEnded = useCallback(() => {
    if (currentIndex < songs.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setCurrentIndex(0);
      setIsPlaying(false);
    }
  }, [currentIndex, songs.length]);

  const togglePlay = useCallback(() => {
    setIsPlaying((prev) => !prev);
  }, []);

  const handlePrev = useCallback(() => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : songs.length - 1));
  }, [songs.length]);

  const handleNext = useCallback(() => {
    setCurrentIndex((prev) => (prev < songs.length - 1 ? prev + 1 : 0));
  }, [songs.length]);

  const handleProgressClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (!audioRef.current || !progressRef.current) return;
      const rect = progressRef.current.getBoundingClientRect();
      const percent = (e.clientX - rect.left) / rect.width;
      const newTime = percent * duration;
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    },
    [duration]
  );

  const toggleMute = useCallback(() => {
    if (!audioRef.current) return;
    audioRef.current.muted = !isMuted;
    setIsMuted((prev) => !prev);
  }, [isMuted]);

  const handleVolumeChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    if (audioRef.current) {
      audioRef.current.volume = newVol;
      if (newVol > 0 && isMuted) {
        audioRef.current.muted = false;
        setIsMuted(false);
      }
    }
  }, [isMuted]);

  const toggleLike = useCallback((id: number) => {
    setLiked((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const formatTime = (t: number) => {
    if (!isFinite(t)) return "0:00";
    const m = Math.floor(t / 60);
    const s = Math.floor(t % 60);
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="w-full">
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleEnded}
        onLoadedMetadata={handleTimeUpdate}
      />

      {/* Now Playing */}
      {currentSong && (
        <div className="glass-card rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-5">
            <div className="relative w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
              <img
                src={currentSong.coverUrl}
                alt={currentSong.title}
                className={`w-full h-full object-cover ${isPlaying ? "animate-pulse" : ""}`}
                style={{ animationDuration: "3s" }}
              />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-medium text-[#e2e2e2] truncate">
                {currentSong.title}
              </h3>
              <p className="text-sm text-[#e2e2e2]/50 mt-0.5">{currentSong.artist}</p>
            </div>
            <button
              onClick={() => toggleLike(currentSong.id)}
              className={`p-2 rounded-full transition-all duration-300 ${
                liked.has(currentSong.id)
                  ? "text-red-400"
                  : "text-[#e2e2e2]/30 hover:text-[#e2e2e2]/60"
              }`}
            >
              <Heart size={18} fill={liked.has(currentSong.id) ? "currentColor" : "none"} />
            </button>
          </div>

          {/* Progress */}
          <div className="mt-5">
            <div
              ref={progressRef}
              className="h-1 bg-[#333]/50 rounded-full cursor-pointer group"
              onClick={handleProgressClick}
            >
              <div
                className="h-full bg-[#e2e2e2]/70 rounded-full transition-all duration-100 relative"
                style={{ width: `${progressPercent}%` }}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-[#e2e2e2] rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-[10px] text-[#e2e2e2]/40 font-mono">
                {formatTime(currentTime)}
              </span>
              <span className="text-[10px] text-[#e2e2e2]/40 font-mono">
                {formatTime(duration)}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-5 mt-3">
            <button
              onClick={handlePrev}
              className="p-2 text-[#e2e2e2]/50 hover:text-[#e2e2e2] transition-colors duration-300"
            >
              <SkipBack size={20} />
            </button>
            <button
              onClick={togglePlay}
              className="w-12 h-12 rounded-full bg-[#e2e2e2] text-[#050505] flex items-center justify-center hover:scale-105 active:scale-95 transition-all duration-300"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} className="ml-0.5" />}
            </button>
            <button
              onClick={handleNext}
              className="p-2 text-[#e2e2e2]/50 hover:text-[#e2e2e2] transition-colors duration-300"
            >
              <SkipForward size={20} />
            </button>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-3 mt-4">
            <button onClick={toggleMute} className="text-[#e2e2e2]/40 hover:text-[#e2e2e2]/70 transition-colors">
              {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="flex-1 h-0.5 accent-[#e2e2e2] cursor-pointer"
            />
          </div>
        </div>
      )}

      {/* Playlist */}
      <div className="space-y-1">
        {songs.map((song, idx) => (
          <button
            key={song.id}
            onClick={() => {
              setCurrentIndex(idx);
              setIsPlaying(true);
            }}
            className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all duration-300 group ${
              idx === currentIndex
                ? "bg-[#1c1c1c]/80"
                : "hover:bg-[#1c1c1c]/40"
            }`}
          >
            <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0">
              <img
                src={song.coverUrl}
                alt={song.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0 text-left">
              <p className={`text-sm truncate ${
                idx === currentIndex ? "text-[#e2e2e2]" : "text-[#e2e2e2]/70 group-hover:text-[#e2e2e2]"
              } transition-colors`}>
                {song.title}
              </p>
              <p className="text-xs text-[#e2e2e2]/40 truncate">{song.artist}</p>
            </div>
            {idx === currentIndex && isPlaying && (
              <div className="flex items-end gap-0.5 h-3">
                <div className="w-0.5 bg-[#e2e2e2]/60 rounded-full animate-pulse" style={{ height: "60%", animationDelay: "0s" }} />
                <div className="w-0.5 bg-[#e2e2e2]/60 rounded-full animate-pulse" style={{ height: "100%", animationDelay: "0.15s" }} />
                <div className="w-0.5 bg-[#e2e2e2]/60 rounded-full animate-pulse" style={{ height: "40%", animationDelay: "0.3s" }} />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
