import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Music, Image, Settings, LogOut, LogIn, Menu, X } from "lucide-react";

export default function Navigation() {
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isHome = location.pathname === "/";
  const isAdmin = location.pathname === "/admin";
  const isAdminUser = user?.role === "admin";

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-[1000] transition-all duration-500 ${
        scrolled || !isHome
          ? "bg-[#050505]/80 backdrop-blur-xl border-b border-[#333]/30"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-16">
          <Link
            to="/"
            className="font-mono text-sm tracking-[0.1em] uppercase text-[#e2e2e2] hover:text-white transition-colors duration-300"
          >
            Reminiscence
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {isHome && (
              <>
                <a
                  href="#gallery"
                  className="flex items-center gap-2 text-xs tracking-[0.1em] uppercase text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors duration-300"
                >
                  <Image size={14} />
                  Gallery
                </a>
                <a
                  href="#music"
                  className="flex items-center gap-2 text-xs tracking-[0.1em] uppercase text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors duration-300"
                >
                  <Music size={14} />
                  Music
                </a>
              </>
            )}

            {!isHome && !isAdmin && (
              <Link
                to="/"
                className="flex items-center gap-2 text-xs tracking-[0.1em] uppercase text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors duration-300"
              >
                Home
              </Link>
            )}

            {isAdminUser && (
              <Link
                to={isAdmin ? "/" : "/admin"}
                className="flex items-center gap-2 text-xs tracking-[0.1em] uppercase text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors duration-300"
              >
                <Settings size={14} />
                {isAdmin ? "Home" : "Dashboard"}
              </Link>
            )}

            {isAuthenticated ? (
              <button
                onClick={logout}
                className="flex items-center gap-2 text-xs tracking-[0.1em] uppercase text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors duration-300"
              >
                <LogOut size={14} />
                Exit
              </button>
            ) : (
              <a
                href="/api/oauth/callback"
                className="flex items-center gap-2 text-xs tracking-[0.1em] uppercase text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors duration-300"
              >
                <LogIn size={14} />
                Login
              </a>
            )}
          </div>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden bg-[#050505]/95 backdrop-blur-xl border-t border-[#333]/30">
          <div className="px-6 py-6 flex flex-col gap-4">
            {isHome && (
              <>
                <a
                  href="#gallery"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors"
                >
                  <Image size={16} />
                  Gallery
                </a>
                <a
                  href="#music"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors"
                >
                  <Music size={16} />
                  Music
                </a>
              </>
            )}
            {!isHome && (
              <Link
                to="/"
                onClick={() => setMobileOpen(false)}
                className="text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors"
              >
                Home
              </Link>
            )}
            {isAdminUser && (
              <Link
                to={isAdmin ? "/" : "/admin"}
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-3 text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors"
              >
                <Settings size={16} />
                {isAdmin ? "Home" : "Dashboard"}
              </Link>
            )}
            {isAuthenticated ? (
              <button
                onClick={() => {
                  logout();
                  setMobileOpen(false);
                }}
                className="flex items-center gap-3 text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors"
              >
                <LogOut size={16} />
                Exit
              </button>
            ) : (
              <a
                href="/api/oauth/callback"
                className="flex items-center gap-3 text-sm text-[#e2e2e2]/60 hover:text-[#e2e2e2] transition-colors"
              >
                <LogIn size={16} />
                Login
              </a>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
