import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { photos } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const photoRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(photos).orderBy(desc(photos.createdAt));
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(photos)
        .where(eq(photos.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        imageUrl: z.string().url(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(photos).values({
        title: input.title,
        description: input.description ?? null,
        imageUrl: input.imageUrl,
      });
      const insertId = Number(result[0].insertId);
      return {
        id: insertId,
        title: input.title,
        description: input.description ?? null,
        imageUrl: input.imageUrl,
        createdAt: new Date(),
      };
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...updates } = input;
      await db.update(photos).set(updates).where(eq(photos.id, id));
      const result = await db
        .select()
        .from(photos)
        .where(eq(photos.id, id))
        .limit(1);
      return result[0]!;
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(photos).where(eq(photos.id, input.id));
      return { success: true };
    }),
});
