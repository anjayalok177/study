import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { songs } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const songRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(songs).orderBy(desc(songs.createdAt));
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(songs)
        .where(eq(songs.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        artist: z.string().min(1),
        audioUrl: z.string().url(),
        coverUrl: z.string().url(),
        duration: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(songs).values({
        title: input.title,
        artist: input.artist,
        audioUrl: input.audioUrl,
        coverUrl: input.coverUrl,
        duration: input.duration ?? 0,
      });
      const insertId = Number(result[0].insertId);
      return {
        id: insertId,
        title: input.title,
        artist: input.artist,
        audioUrl: input.audioUrl,
        coverUrl: input.coverUrl,
        duration: input.duration ?? 0,
        createdAt: new Date(),
      };
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        artist: z.string().optional(),
        audioUrl: z.string().optional(),
        coverUrl: z.string().optional(),
        duration: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...updates } = input;
      await db.update(songs).set(updates).where(eq(songs.id, id));
      const result = await db
        .select()
        .from(songs)
        .where(eq(songs.id, id))
        .limit(1);
      return result[0]!;
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(songs).where(eq(songs.id, input.id));
      return { success: true };
    }),
});
