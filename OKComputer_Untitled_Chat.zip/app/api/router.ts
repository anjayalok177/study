import { authRouter } from "./auth-router";
import { createRouter, publicQuery } from "./middleware";
import { songRouter } from "./routers/song";
import { photoRouter } from "./routers/photo";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  song: songRouter,
  photo: photoRouter,
});

export type AppRouter = typeof appRouter;
