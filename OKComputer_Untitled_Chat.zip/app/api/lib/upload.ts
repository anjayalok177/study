import { Hono } from "hono";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";

const uploadApp = new Hono();

const UPLOAD_DIR = "public/uploads";
const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_AUDIO_SIZE = 50 * 1024 * 1024; // 50MB

const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
const ALLOWED_AUDIO_TYPES = ["audio/mpeg", "audio/mp3", "audio/wav", "audio/ogg", "audio/x-m4a", "audio/aac"];

uploadApp.post("/api/upload", async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get("file") as File | null;
    const type = formData.get("type") as string | null; // "image" or "audio"

    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }

    const maxSize = type === "audio" ? MAX_AUDIO_SIZE : MAX_IMAGE_SIZE;
    if (file.size > maxSize) {
      return c.json(
        { error: `File too large. Max size: ${maxSize / 1024 / 1024}MB` },
        400
      );
    }

    if (type === "audio") {
      if (!ALLOWED_AUDIO_TYPES.includes(file.type)) {
        return c.json(
          { error: `Invalid audio type: ${file.type}` },
          400
        );
      }
    } else {
      if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
        return c.json(
          { error: `Invalid image type: ${file.type}` },
          400
        );
      }
    }

    // Generate unique filename
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const ext = file.name.split(".").pop() || (type === "audio" ? "mp3" : "jpg");
    const filename = `${timestamp}-${randomStr}.${ext}`;

    // Ensure upload directory exists
    await mkdir(UPLOAD_DIR, { recursive: true });

    // Save file
    const filepath = join(UPLOAD_DIR, filename);
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(filepath, buffer);

    // Return URL
    const url = `/uploads/${filename}`;
    return c.json({ url });
  } catch (error) {
    console.error("Upload error:", error);
    return c.json({ error: "Upload failed" }, 500);
  }
});

export default uploadApp;
